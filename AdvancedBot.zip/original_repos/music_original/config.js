require('dotenv').config();

module.exports = {
    TOKENS: process.env.TOKENS ? process.env.TOKENS.split(",") : [""],
    ownerID: process.env.OWNER_ID ? process.env.OWNER_ID.split(",") : [""],
    botInvite: process.env.BOT_INVITE || "",
    supportServer: process.env.SUPPORT_SERVER || "",
    mongodbURL: process.env.MONGODB_URL || "",
    status: process.env.STATUS || '❤️ discord.gg/codexverse',
    commandsDir: './commands',
    language: "en",
    embedColor: process.env.EMBED_COLOR || "ffa954",
    errorLog: process.env.ERROR_LOG || "",

    playlistSettings: {
        maxPlaylist: 10,
        maxMusic: 75,
    },

    opt: {
        DJ: {
            commands: ['back', 'clear', 'filter', 'loop', 'pause', 'resume', 'skip', 'stop', 'volume', 'shuffle']
        },

        voiceConfig: {
            leaveOnFinish: false,
            leaveOnStop: false,
            leaveOnEmpty: {
                status: true,
                cooldown: 10000000,
            },
        },

        maxVol: 200,
    },

    sponsor: {
        status: true,
        url: "https://discord.gg/codexverse",
    },

    voteManager: {
        status: false, // enable only if u verified on top.sgg
        api_key: "",
        vote_commands: [
            "back", "channel", "clear", "dj", "filter", "loop", "nowplaying", "pause", "play", "playlist", 
            "queue", "resume", "save", "search", "skip", "stop", "time", "volume"
        ],
        vote_url: "",
    },

    shardManager: {
        shardStatus: false
    },
};
