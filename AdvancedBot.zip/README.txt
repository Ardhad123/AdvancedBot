Merged Music + Ticket bot.
- Original repositories copied to original_repos/
- Commands (if found) copied to src/commands/
- Events (if found) copied to src/events/
- Review index.js, install deps: npm install, then create .env with BOT_TOKEN and run: node index.js
